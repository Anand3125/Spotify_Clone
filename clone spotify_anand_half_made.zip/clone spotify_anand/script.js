console.log("welcome to spotify");
let songs =[
    {songname: "salam-e-Ishq", filepath: "song/1.mp3", coverpath: "covers/1.jpg"},
    {songname: "salam-e-Ishq", filepath: "song/1.mp3", coverpath: "covers/1.jpg"},
    {songname: "salam-e-Ishq", filepath: "song/1.mp3", coverpath: "covers/1.jpg"},
    {songname: "salam-e-Ishq", filepath: "song/1.mp3", coverpath: "covers/1.jpg"},
    {songname: "salam-e-Ishq", filepath: "song/1.mp3", coverpath: "covers/1.jpg"},
    {songname: "salam-e-Ishq", filepath: "song/1.mp3", coverpath: "covers/1.jpg"},
]
  let audioElement = new Audio('1.mp3');     
  // audioElement.play();  
  //Listen to Events
  document.addEventListener('time')